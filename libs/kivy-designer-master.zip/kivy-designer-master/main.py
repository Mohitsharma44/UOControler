if __name__ == '__main__':
    from designer.app import DesignerApp
    DesignerApp().run()
